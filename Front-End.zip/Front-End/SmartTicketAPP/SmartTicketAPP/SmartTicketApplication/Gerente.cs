﻿namespace SmartTicketApplication
{
    public class Gerente : User
    {
        
    }
}